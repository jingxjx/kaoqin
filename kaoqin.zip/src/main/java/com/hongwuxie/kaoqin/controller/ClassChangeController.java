package com.hongwuxie.kaoqin.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hongwuxie.kaoqin.entities.ClassEntity;
import com.hongwuxie.kaoqin.entities.StudentEntity;
import com.hongwuxie.kaoqin.service.ClassDao;
import com.hongwuxie.kaoqin.service.StudentDao;

@Controller
public class ClassChangeController {
    @Autowired
    ClassDao classDao;
    @Autowired
    StudentDao studentDao;

    @RequestMapping("/classchangemanagement")
    public String changeClass(Model model, int id) {
        StudentEntity stud = studentDao.findById(id);
        String className = stud.getClassName();
        String classDate = stud.getClassDate();
        
        List<ClassEntity> classes = classDao.findAll();
        model.addAttribute("changeClassNameFrom", className);
        model.addAttribute("changeClassDateFrom", classDate);
        model.addAttribute("student", stud);
        model.addAttribute("classes", classes);
        return "classchangemanagement";
    }
    
    
    @RequestMapping("/classchangemanagement/classtime")
    @ResponseBody
    public String getClassTime(String className) {
        return classDao.getClassTimeByClassName(className);
    }
    
    @RequestMapping("/classchangemanagement/changeclass")
    public String submitChange(Model model, int studentId, String classNameChangeFrom, String classChangeDateFrom, String classNameChangeTo, String classChangeDateTo) {
        StudentEntity stud = studentDao.findById(studentId);
        Map<String, String> reschedule = new HashMap<String, String>();
        reschedule.put(classNameChangeTo, classChangeDateTo);
        stud.setReschedule(reschedule);
        studentDao.save(stud);
        return "redirect:/studentmanagement";
    }
    
}
