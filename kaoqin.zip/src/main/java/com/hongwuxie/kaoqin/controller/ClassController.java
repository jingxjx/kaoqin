package com.hongwuxie.kaoqin.controller;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.hongwuxie.kaoqin.entities.ClassEntity;
import com.hongwuxie.kaoqin.requestParam.ClassNew;
import com.hongwuxie.kaoqin.service.ClassDao;
import com.hongwuxie.kaoqin.service.StudentDao;

@Controller
public class ClassController {
    @Autowired
    StudentDao studentDao;
    
    @Autowired
    ClassDao classDao;
    
    @RequestMapping("/classmanagement")
    public String allClasses(Model model) {
        List<ClassEntity> classList = classDao.findAll();
        for(ClassEntity cls: classList) {
            String clsName = cls.getClassName();
            int studentCount = studentDao.getStudentCountByClassName(clsName);
            cls.setStudentCount(studentCount);
        }
        model.addAttribute("classes", classList);
        return "classmanagement";
    }
    
    @RequestMapping("/classmanagement/today")
    public String classToday(Model model) {
        List<ClassEntity> classList = classDao.findAll();
        String today = getDayOfToday();
        List<ClassEntity> classToday = new ArrayList<ClassEntity>();
        for(ClassEntity cls: classList) {
            String clsName = cls.getClassName();
            String date = cls.getClassDate();
            if (date.contains(today)) {
                int studentCount = studentDao.getStudentCountByClassName(clsName);
                cls.setStudentCount(studentCount);
                classToday.add(cls);
            }
        }
        model.addAttribute("classes", classToday);
        return "classmanagement";
    }
    
    @GetMapping("/addclass")
    public String addClass() {
        return "addclass";
    }
    
    @PostMapping("/addclass")
    public ModelAndView addClass(ModelAndView mv, @Valid ClassNew classNew, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            mv.addObject("error", bindingResult.getFieldError().getDefaultMessage());
            mv.setViewName("addclass");
            return mv;
        }

        ClassEntity classEntity = new ClassEntity();
        classEntity.setClassName(classNew.getClassName());
        classEntity.setClassDate(classNew.getClassDate());
        classEntity.setTeacherName(classNew.getTeacherName());
        classEntity.setClassroom(classNew.getClassRoom());
        classDao.save(classEntity);

        mv.setViewName("redirect:/classmanagement");
        return mv;
    }
    
    private String getDayOfToday() {
        Calendar calendar =Calendar.getInstance(Locale.CHINA);
        int day = calendar.getTime().getDay();
        switch(day){
            case 1:
                return "周一";
            case 2: 
                return "周二";
            case 3: 
                return "周三";
            case 4: 
                return "周四";
            case 5: 
                return "周五";
            case 6: 
                return "周六";
            case 0: 
                return "周日";
            default:
                return null;
        }
    }
    
}
