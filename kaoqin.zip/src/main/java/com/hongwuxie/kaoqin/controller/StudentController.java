package com.hongwuxie.kaoqin.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.hongwuxie.kaoqin.entities.CheckInEntity;
import com.hongwuxie.kaoqin.entities.ClassEntity;
import com.hongwuxie.kaoqin.entities.ClassStudentEntity;
import com.hongwuxie.kaoqin.entities.StudentEntity;
import com.hongwuxie.kaoqin.requestParam.CheckInUsers;
import com.hongwuxie.kaoqin.requestParam.Student;
import com.hongwuxie.kaoqin.service.CheckInDao;
import com.hongwuxie.kaoqin.service.ClassDao;
import com.hongwuxie.kaoqin.service.ClassStudentDao;
import com.hongwuxie.kaoqin.service.StudentDao;

@Controller
public class StudentController {
    @Autowired
    StudentDao studentDao;
    @Autowired
    ClassDao classDao;
    @Autowired
    CheckInDao checkInDao;
    @Autowired
    ClassStudentDao classStudentDao;
    
    Logger logger = LoggerFactory.getLogger(StudentController.class);

    @RequestMapping("/home")
    public String homePage() {
        return "home";
    }
    
    @RequestMapping("/student")
    public String studentPage(Model model, int classId, boolean validCheckin, boolean checkedIn) {
        List<StudentEntity> students = studentDao.getStudentsByClassId(classId);
        ClassEntity classEntity = classDao.findById(classId);
        String className = classEntity.getClassName();

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String today = format.format(new Date());
        
        // 添加本周插班生
        List<StudentEntity> allStud = studentDao.getAllStudents();
        for (StudentEntity student: allStud) {
            if (isChangedToThisClassThisWeek(student, className)) {
                students.add(student);
            }
        }
        
        for (StudentEntity student: students) {
            int studentId = student.getId();
            CheckInEntity checkinEntity = checkInDao.getCheckInEntityByStudentId(studentId);
            if (checkinEntity.getCheckInDate().contains(today)) {
                student.setCheckInToday(true);
            } else if (checkinEntity.getAskForLeaveDate().contains(today)){
                student.setCheckInToday(false);
            }
            // 显示是否本周调去其他班
            student.setIsClassChangedThisWeek(isClassChangedThisWeek(student));
        }
        
        model.addAttribute("students", students);
        model.addAttribute("classEntity", classEntity);
        model.addAttribute("validCheckin", validCheckin);
        model.addAttribute("checkedIn", checkedIn);
        return "student";
    }
    
    @PostMapping(value="/student/checkin", params="checkInAction=签到")
    public String studentCheckIn(Model model, @Valid CheckInUsers users, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "classmanagement";
        }
        boolean res = studentCheckIn(users, true);
        model.addAttribute("validCheckin", res);
        model.addAttribute("checkedIn", true);
        return "redirect:/student?classId=" + users.getClassId() + "&validCheckin=" + res + "&checkedIn=true";
    }
    
    @PostMapping(value="/student/checkin", params="checkInAction=请假")
    public String studentAskForLeave(Model model, @Valid CheckInUsers users, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "classmanagement";
        }
        boolean res = studentCheckIn(users, false);
        model.addAttribute("checkedIn", false);
        model.addAttribute("validCheckin", res);
        
        return "redirect:/student?classId=" + users.getClassId() + "&validCheckin=" + res + "&checkedIn=false";
    }
    
    @RequestMapping("/studentmanagement")
    public String studentManagementPage(Model model) {
        List<StudentEntity> allStudents = studentDao.getAllStudents();
        model.addAttribute("students", allStudents);
        return "studentmanagement";
    }
    
    @GetMapping("/addmember")
    public String addMember(Model model) {
        List<ClassEntity> allCls = classDao.findAll();
        model.addAttribute("classes", allCls);
        return "addmember";
    }
    
    @PostMapping("/addmember")
    public ModelAndView addMember(ModelAndView mv, @Valid Student addedStudent, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            mv.addObject("error", bindingResult.getFieldError().getDefaultMessage());
            mv.setViewName("addmember");
            return mv;
        }

        StudentEntity student = new StudentEntity();
        student.setClassCostCount(addedStudent.getClassCostCount());
        student.setClassCount(addedStudent.getClassCount());
        student.setClassName(addedStudent.getClassName());
        student.setName(addedStudent.getName());
        student.setTeacherName(addedStudent.getTeacherName());
        student.setTelphone(addedStudent.getTelphone());
        student.setClassDate(addedStudent.getClassDate());
        student.setAge(addedStudent.getAge());
        student.setClassId(classDao.getClassByClassName(addedStudent.getClassName()).getClassId());
        studentDao.save(student);

        int classId = classDao.getClassByClassName(addedStudent.getClassName()).getClassId();
        
        CheckInEntity checkInEntity = new CheckInEntity();
        checkInEntity.setClassId(classId);
        checkInEntity.setClassName(addedStudent.getClassName());
        checkInEntity.setStudentId(student.getId());
        checkInEntity.setStudentName(addedStudent.getName());
        checkInDao.save(checkInEntity);
        
        
        ClassStudentEntity classStudentEntity = new ClassStudentEntity();
        classStudentEntity.setClassId(classId);
        classStudentEntity.setStudentId(student.getId());
        classStudentDao.save(classStudentEntity);
        
        mv.setViewName("redirect:/studentmanagement");
        return mv;
    }

    @GetMapping("/studentmanagement/delete")
    public ModelAndView deleleStudent(ModelAndView mv, @RequestParam int id) {
        studentDao.deleteStudentById(id);
        mv.setViewName("redirect:/studentmanagement");
        return mv;
    }
    
    @GetMapping("/studentmanagement/edit")
    public String editStudent(Model model, @RequestParam int id) {
        StudentEntity student = studentDao.findById(id);
        List<ClassEntity> classes = classDao.findAll();
        
        model.addAttribute("student", student);
        model.addAttribute("classes", classes);
        return "editmember";
    }
    
    @PostMapping("/studentmanagement/edit")
    public String editStudentAndSave(Model model,  @Valid Student editedStudent, BindingResult bindingResult) {
        StudentEntity student = studentDao.findById(editedStudent.getId());
        student.setAge(editedStudent.getAge());
        student.setClassCostCount(editedStudent.getClassCostCount());
        student.setClassCount(editedStudent.getClassCount());
        student.setClassDate(editedStudent.getClassDate());
        student.setClassName(editedStudent.getClassName());
        student.setTeacherName(editedStudent.getTeacherName());
        student.setTelphone(editedStudent.getTelphone());
        student.setName(editedStudent.getName());
        
        studentDao.save(student);
        return "redirect:/studentmanagement";
    }
    
    @RequestMapping("/addmember/classinfo")
    @ResponseBody
    public ClassEntity getClassTime(String className) {
        return classDao.getClassByClassName(className);
    }
    
    @RequestMapping("/student/checkinstatus")
    public String getCheckinStatus(Model model, int studentId) {
        CheckInEntity checkinEntity = checkInDao.getCheckInEntityByStudentId(studentId);
        List<String> checkinDates = checkinEntity.getCheckInDate();
        List<String> askForLeaveDates = checkinEntity.getAskForLeaveDate();

        StudentEntity student = studentDao.findById(studentId);
        model.addAttribute("checkinDates", checkinDates);
        model.addAttribute("askForLeaveDates", askForLeaveDates);
        model.addAttribute("checkinDays", checkinDates.size());
        model.addAttribute("askForLeaveDays", askForLeaveDates.size());
        model.addAttribute("student", student);
        
        return "checkinstatus";
    }
    
    private boolean studentCheckIn(CheckInUsers users, boolean checkin) {
        List<Integer> checkedInUsers = users.getCheckInStudents();
        String date = users.getCheckInDate();
        boolean needSaveCheckInEntity = false;
        boolean res = false;
        for(int id: checkedInUsers) {
            CheckInEntity checkInEntity = checkInDao.getCheckInEntityByStudentId(id);
            StudentEntity student = studentDao.findById(id);
            if (checkInEntity == null) {
                checkInEntity = new CheckInEntity();
                checkInEntity.setStudentId(id);
                needSaveCheckInEntity = true;
            } 
            List<String> checkInDate = checkInEntity.getCheckInDate();
            List<String> askForLeaveDate = checkInEntity.getAskForLeaveDate();
            if (checkin) {
                if (!checkInDate.contains(date)) {
                 // 如果之前请假过这一天， 则从请假中去掉，保存在签到中，场景是：之前本来想签到，但是点错成请假了
                    if (askForLeaveDate.contains(date)) {
                        askForLeaveDate.remove(date);
                        checkInEntity.setAskForLeaveDate(askForLeaveDate);
                    }
                    checkInDate.add(date);
                    checkInEntity.setCheckInDate(checkInDate);
                    student.setClassCostCount(student.getClassCostCount() + 1);
                    studentDao.save(student);
                    needSaveCheckInEntity = true;
                    res = true;
                }

            } else {
                if (!askForLeaveDate.contains(date)) {
                    if (checkInDate.contains(date)) {
                        checkInDate.remove(date);
                        checkInEntity.setCheckInDate(checkInDate);
                        student.setClassCostCount(student.getClassCostCount() + 1);
                    }
                    askForLeaveDate.add(date);
                    checkInEntity.setAskForLeaveDate(askForLeaveDate);
                    needSaveCheckInEntity = true;
                    res = true;
                }
            }
            if (needSaveCheckInEntity) {
                checkInDao.save(checkInEntity);
            }
        }
        return res;
    }
    
    
    private Boolean isClassChangedThisWeek(StudentEntity student) {
        Map<String, String> reschedule = student.getReschedule();
        Collection<String> changedToDates = reschedule.values();
        for(String changedToDate: changedToDates) {
            if (isDateInThisWeek(changedToDate)) {
                return true;
            }
        }
        return false;
    }
    
    private Boolean isDateInThisWeek(String changedToDate) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date chanedToTime;
        try {
            chanedToTime = sdf.parse(changedToDate);
        } catch (ParseException e) {
            logger.error("the date format is wrong, cannot parse to time");
            return false;
        }
        Calendar calendar =Calendar.getInstance(Locale.CHINA);
        int currentWeek = calendar.get(Calendar.WEEK_OF_YEAR);
        calendar.setTime(chanedToTime);
        int paramWeek = calendar.get(Calendar.WEEK_OF_YEAR);
        return paramWeek == currentWeek;
    }
    
    
    private boolean isChangedToThisClassThisWeek(StudentEntity student, String classNameChangeTo) {
        Map<String, String> reschedule = student.getReschedule();
        Set<String> changedToClasses = reschedule.keySet();
        
        return changedToClasses.contains(classNameChangeTo) && isDateInThisWeek(reschedule.get(classNameChangeTo));
    }
}
