package com.hongwuxie.kaoqin.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.hongwuxie.kaoqin.util.Convertor;

@Entity
@Table(name = "checkin")
//@Data
public class CheckInEntity {
    @Id
    @GeneratedValue
    private Integer id;
    
    @Column
    private Integer classId;
    
    @Column
    private String className;
    
    @Column
    private Integer studentId;
    
    @Column
    private String studentName;
    
    @Column
    private String checkInDate;
    
    @Column
    private String askForLeaveDate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getClassId() {
        return classId;
    }

    public void setClassId(Integer classId) {
        this.classId = classId;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public List<String> getCheckInDate() {
        return Convertor.convertStringToList(checkInDate);
    }

    public void setCheckInDate(List<String> checkInDate) {
        this.checkInDate = Convertor.convertListToString(checkInDate);
    }

    public List<String> getAskForLeaveDate() {
        return Convertor.convertStringToList(askForLeaveDate);
    }

    public void setAskForLeaveDate(List<String> askForLeaveDate) {
        this.askForLeaveDate = Convertor.convertListToString(askForLeaveDate);
    }

}
