package com.hongwuxie.kaoqin.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "class")
@Data
public class ClassEntity {
    @Id
    @GeneratedValue
    private Integer classId;
    
    @Column
    private String className;
    
    @Column
    private String teacherName;
    
    @Column
    private String classDate;
    
    @Column
    private String classroom;
    
    private int studentCount;
}
