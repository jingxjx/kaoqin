package com.hongwuxie.kaoqin.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "class_student")
@Data
public class ClassStudentEntity {
    @Id
    @GeneratedValue
    private int id;
    
    @Column
    private int classId;
    @Column
    private int studentId;
}
