package com.hongwuxie.kaoqin.entities;

import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.hongwuxie.kaoqin.util.Convertor;

@Entity
@Table(name = "student")
public class StudentEntity {
    @Id
    @GeneratedValue
    private int id;
    
    @Column
    private String name;
    @Column
    private int age;
    @Column
    private String telphone;
    @Column
    private String className;
    @Column
    private String teacherName;
    @Column
    private String classDate;
    @Column
    private int classCount;
    @Column
    private int classCostCount;
    @Column
    private String reschedule;
    @Column
    private int classId;
    
    
    private Boolean checkInToday;
    
    private Boolean isClassChangedThisWeek;


    public int getId() {
        return id;
    }


    public void setId(int id) {
        this.id = id;
    }


    public String getName() {
        return name;
    }


    public void setName(String name) {
        this.name = name;
    }


    public int getAge() {
        return age;
    }


    public void setAge(int age) {
        this.age = age;
    }


    public String getTelphone() {
        return telphone;
    }


    public void setTelphone(String telphone) {
        this.telphone = telphone;
    }


    public String getClassName() {
        return className;
    }


    public void setClassName(String className) {
        this.className = className;
    }


    public String getTeacherName() {
        return teacherName;
    }


    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }


    public String getClassDate() {
        return classDate;
    }


    public void setClassDate(String classDate) {
        this.classDate = classDate;
    }


    public int getClassCount() {
        return classCount;
    }


    public void setClassCount(int classCount) {
        this.classCount = classCount;
    }


    public int getClassCostCount() {
        return classCostCount;
    }


    public void setClassCostCount(int classCostCount) {
        this.classCostCount = classCostCount;
    }


    public Map<String, String> getReschedule() {
        return Convertor.convertStringToMap(this.reschedule);
    }


    public void setReschedule(Map<String, String> reschedule) {
        this.reschedule = Convertor.convertMapToString(reschedule);
    }


    public Boolean getCheckInToday() {
        return checkInToday;
    }


    public void setCheckInToday(Boolean checkInToday) {
        this.checkInToday = checkInToday;
    }


    public Boolean getIsClassChangedThisWeek() {
        return isClassChangedThisWeek;
    }


    public void setIsClassChangedThisWeek(Boolean isClassChangedThisWeek) {
        this.isClassChangedThisWeek = isClassChangedThisWeek;
    }


    public int getClassId() {
        return classId;
    }


    public void setClassId(int classId) {
        this.classId = classId;
    }
    
}
