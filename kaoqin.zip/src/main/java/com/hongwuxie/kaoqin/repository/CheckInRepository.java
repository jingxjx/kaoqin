package com.hongwuxie.kaoqin.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hongwuxie.kaoqin.entities.CheckInEntity;

public interface CheckInRepository extends JpaRepository<CheckInEntity, Integer>{
    @Query(value="SELECT checkInEntity FROM CheckInEntity checkInEntity WHERE checkInEntity.studentId=?1")
    CheckInEntity findOneByStudentId(int studentId);
}
