package com.hongwuxie.kaoqin.repository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hongwuxie.kaoqin.entities.ClassEntity;

public interface ClassRepository extends JpaRepository<ClassEntity, Integer>{
    Logger logger = LoggerFactory.getLogger(ClassRepository.class);

    @Query(value="SELECT cls FROM ClassEntity cls WHERE cls.className=?1")
    ClassEntity findOneByClassName(String className);
    
    @Query(value="SELECT cls.className FROM ClassEntity cls WHERE cls.classId=?1")
    String getClassNameById(int id);
}
