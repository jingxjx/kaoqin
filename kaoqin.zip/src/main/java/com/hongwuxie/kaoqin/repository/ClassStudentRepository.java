package com.hongwuxie.kaoqin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hongwuxie.kaoqin.entities.ClassStudentEntity;

public interface ClassStudentRepository extends JpaRepository<ClassStudentEntity, Integer>{

}
