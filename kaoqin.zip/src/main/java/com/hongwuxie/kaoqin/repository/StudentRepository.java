package com.hongwuxie.kaoqin.repository;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hongwuxie.kaoqin.entities.StudentEntity;

public interface StudentRepository extends JpaRepository<StudentEntity, Integer>{
    Logger logger = LoggerFactory.getLogger(StudentEntity.class);
    
    @Query(value="SELECT stud FROM StudentEntity stud WHERE stud.className=?1")
    List<StudentEntity> getStudentsByClassName(String className);
    
    @Query(value="SELECT stud.className FROM StudentEntity stud WHERE stud.id=?1")
    String getClassNameByStudentId(int studentId);
}
