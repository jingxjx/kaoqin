package com.hongwuxie.kaoqin.requestParam;

import java.util.List;

import lombok.Data;

@Data
public class CheckInUsers {
    private long Id;
    
    private List<Integer> checkInStudents;
    
    private String checkInDate;
    
    private int classId;
}
