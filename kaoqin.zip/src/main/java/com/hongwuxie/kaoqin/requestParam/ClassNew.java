package com.hongwuxie.kaoqin.requestParam;

import org.hibernate.validator.constraints.NotEmpty;

import lombok.Data;

@Data
public class ClassNew {
    private long Id;
    
    @NotEmpty(message = "班级名称不能为空")
    private String className;
    
    @NotEmpty(message = "老师姓名不能为空")
    private String teacherName;
    
    @NotEmpty(message = "上课时间不能为空")
    private String classDate;
    
    @NotEmpty(message = "教室不能为空")
    private String classRoom;
}
