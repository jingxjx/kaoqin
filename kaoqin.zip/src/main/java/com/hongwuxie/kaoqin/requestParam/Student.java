package com.hongwuxie.kaoqin.requestParam;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

import lombok.Data;

@Data
public class Student {
    private int Id;
    
    @NotEmpty(message = "姓名不能为空")
    private String name;
    
    @NotNull(message = "年龄不能为空")
    private int age;
    
    @Size(min = 11, max = 11, message = "手机号码错误")
    private String password;
    
    @NotEmpty(message = "班级不能为空")
    private String className;
    
    @NotEmpty(message = "老师姓名不能为空")
    private String teacherName;
    
    @NotEmpty(message = "电话不能为空")
    private String telphone;
    
    @NotEmpty(message = "上课时间不能为空")
    private String classDate;
    
    @NotNull(message = "课程总数不能为空")
    private int classCount;
    
    @NotNull(message = "已上课程数不能为空")
    private int classCostCount;
}
