package com.hongwuxie.kaoqin.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hongwuxie.kaoqin.entities.CheckInEntity;
import com.hongwuxie.kaoqin.repository.CheckInRepository;

@Service
public class CheckInDao {
    @Autowired
    private CheckInRepository repo;
    
    public void save(CheckInEntity checkInEntity) {
        repo.save(checkInEntity);
    }
    
    public CheckInEntity getCheckInEntityByStudentId(int studentId) {
        return repo.findOneByStudentId(studentId);
    }
}
