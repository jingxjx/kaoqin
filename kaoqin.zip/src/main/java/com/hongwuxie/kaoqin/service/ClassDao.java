package com.hongwuxie.kaoqin.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.thymeleaf.util.StringUtils;

import com.hongwuxie.kaoqin.entities.ClassEntity;
import com.hongwuxie.kaoqin.repository.ClassRepository;

@Service
public class ClassDao {

    @Autowired
    private ClassRepository repo;
    
    public void save(ClassEntity classEntity) {
        repo.save(classEntity);
    }
    
    public ClassEntity findById(Integer id) {
        return repo.findOne(id);
    }
    
    public List<ClassEntity> findAll() {
        return repo.findAll();
    }
    
    public int getClassCount() {
        return repo.findAll().size();
    }
    
    public String getClassTimeByClassName(String className) {
        List<ClassEntity> classes = repo.findAll();
        Optional<ClassEntity> clsEntity = classes.stream().filter(cls -> StringUtils.equals(cls.getClassName(), className)).findFirst();
        return clsEntity.get().getClassDate();
    }
    
    public ClassEntity getClassByClassName(String className) {
        return repo.findOneByClassName(className);
    }
    
    
    public String getClassNameById(int id) {
        return repo.getClassNameById(id);
    }
    
}
