package com.hongwuxie.kaoqin.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hongwuxie.kaoqin.entities.ClassStudentEntity;
import com.hongwuxie.kaoqin.repository.ClassStudentRepository;

@Service
public class ClassStudentDao {
    @Autowired
    private ClassStudentRepository repo;
    
    public void save(ClassStudentEntity entity) {
        repo.save(entity);
    }
    
}
