package com.hongwuxie.kaoqin.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.thymeleaf.util.StringUtils;

import com.hongwuxie.kaoqin.entities.StudentEntity;
import com.hongwuxie.kaoqin.repository.StudentRepository;

@Service
public class StudentDao {

    @Autowired
    private StudentRepository repo;
    @Autowired
    private ClassDao classDao;
    
    public void save(StudentEntity studentEntity) {
        repo.save(studentEntity);
    }
    
    public StudentEntity findById(Integer id) {
        return repo.findOne(id);
    }
    
    public int getStudengCount() {
        return repo.findAll().size();
    }
    
    public List<StudentEntity> getAllStudents() {
        return repo.findAll();
    }
    
    public List<StudentEntity> getStudentsByClassName(String className) {
        return repo.getStudentsByClassName(className);
    }
    
    public List<StudentEntity> getStudentsByClassId(int classId) {
        String className = classDao.getClassNameById(classId);
        return repo.getStudentsByClassName(className);
    }
    
    public void deleteStudentById(int id) {
        repo.delete(id);
    }
    
    public int getStudentCountByClassName(String className) {
        List<StudentEntity> students = repo.findAll();
        List<StudentEntity> studFiltered = students.stream().filter(stud -> StringUtils.equals(stud.getClassName(), className)).collect(Collectors.toList());
        return studFiltered.size();
    }
    
    public String getClassNameByStudentId(int studentId) {
        return repo.getClassNameByStudentId(studentId);
    }
    
    
}
