package com.hongwuxie.kaoqin.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Convertor {
    private static Logger logger = LoggerFactory.getLogger(Convertor.class);
    public static final ObjectMapper OBJECTMAPPER = new ObjectMapper()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    
    
    public static String convertListToString(List<String> list) {
        String string = null;
        try {
            if (list != null && list.size() > 0) {
                string = OBJECTMAPPER.writeValueAsString(list);
            }
        } catch (JsonProcessingException e) {
            logger.error("failed convert list to json string, list:{}, error:{}", list,
                e.getMessage());
        }
        return string;
    }
    
    public static List<String> convertStringToList(String string) {
        List<String> list = new ArrayList<String>();
        try {
            if (string != null) {
                list = OBJECTMAPPER.readValue(string, new TypeReference<List<String>>() {
                });
            }
        } catch (Exception e) {
            logger.error("failed convert json string to Map<String, Double> , string:{}, error:{}", string,
                    e.getMessage());
        }
        return list;
    }
    
    
    public static String convertMapToString(Map<String, String> map) {
        String string = null;
        try {
            if (map != null && map.size() > 0) {
                string = OBJECTMAPPER.writeValueAsString(map);
            }
        } catch (JsonProcessingException e) {
            logger.error("failed convert list to json string, list:{}, error:{}", map,
                e.getMessage());
        }
        return string;
    }
    
    public static Map<String, String> convertStringToMap(String string) {
        Map<String, String> map = new HashMap<String, String>();
        try {
            if (string != null) {
                map = OBJECTMAPPER.readValue(string, new TypeReference<Map<String, String>>() {
                });
            }
        } catch (Exception e) {
            logger.error("failed convert json string to Map<String, Double> , string:{}, error:{}", string,
                    e.getMessage());
        }
        return map;
    }
}
