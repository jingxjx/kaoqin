$(document).ready(function(){
	    $("#className").change(function(){
	       var clsName = $("#className").val(); 
	       if(clsName ==''){ 
	           return; 
	     }

	   $.ajax({ 
	   url:'/addmember/classinfo', 
	   async:false, 
	   type:'post', 
	   data:{className:clsName}, 
	                       success:function(data){ 
	                           var classDate = $("#classDate").empty(); 
	                           classDate.val(data.classDate); 
	                           var teacherName = $("#teacherName").empty(); 
	                           teacherName.val(data.teacherName); 
	                       } 
	   })
	});
});