$(document).ready(function(){
	    $("#classNameChangeTo").change(function(){
	       var classNameChangeTo = $("#classNameChangeTo").val(); 
	       if(classNameChangeTo ==''){ 
	           return; 
	     }

	   $.ajax({ 
	   url:'/classchangemanagement/classtime', 
	                       async:false, 
	   type:'post', 
	   data:{className:classNameChangeTo}, 
	                       success:function(data){ 
	                           var classTime = $("#classTimeChangedTo").empty(); 
	
	                           classTime.append("<span>"+ data+"</span"); 
	                       } 
	   })
	});
});