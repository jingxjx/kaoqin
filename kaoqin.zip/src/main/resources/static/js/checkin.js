$(document).ready(function(){
	 $('#checkAll').click(function() {
		 if($(this).is(":checked"))
			 $(":input[name='checkInStudents']").prop('checked', true);
		 else
			 $(":input[name='checkInStudents']").prop('checked', false);
	 });
	 
	 document.getElementById('calendar').valueAsDate = new Date();
	 
	 /*var validCheckin = $('#validCheckin').text();
	 if (validCheckin == "false") {
		 var checkedIn = $('#validCheckin').text();
		 if (checkedIn = "true") {
			 alert("已经签过到了~~");
		 } else {
			 alert("已经请过假了~~");
		 }
		 
	 }*/
});